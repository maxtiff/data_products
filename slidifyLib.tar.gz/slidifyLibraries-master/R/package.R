#' slidifyLibraries contains external dependencies required by slidify
#' 
#' @docType package
#' @name slidifyLibraries
#' @author Ramnath Vaidyanathan <\url{http://www.slidify.org}>
NULL